﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace var
{
    class Program
    {
        static void Main(string[] args)
        {
            int x = 5;
            string name = "Ahmad";

            var test = name;
            Console.WriteLine(test);
        }
    }
}
